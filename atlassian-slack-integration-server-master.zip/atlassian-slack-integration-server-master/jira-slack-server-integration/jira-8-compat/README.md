# Atlassian Data Center Integrations for Slack

This package contains Jira 8 specific implementations that would not compile in the main plugin.

The plugin should include this module and call these classes depending on Jira's version.
