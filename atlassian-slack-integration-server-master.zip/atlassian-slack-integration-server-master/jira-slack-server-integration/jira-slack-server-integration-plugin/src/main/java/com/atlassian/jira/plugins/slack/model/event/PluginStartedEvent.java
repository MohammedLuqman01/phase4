package com.atlassian.jira.plugins.slack.model.event;

public class PluginStartedEvent implements PluginEvent {
}
