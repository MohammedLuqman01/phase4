package com.atlassian.jira.plugins.slack.model;

/**
 * This is a marker interface defining our data model objects.
 */
public interface BaseObject {
}
