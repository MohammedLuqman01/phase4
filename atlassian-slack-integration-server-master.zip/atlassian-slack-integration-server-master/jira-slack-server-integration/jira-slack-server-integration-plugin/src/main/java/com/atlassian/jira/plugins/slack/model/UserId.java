package com.atlassian.jira.plugins.slack.model;

public interface UserId {
    String getTeamId();

    String getUserId();
}
