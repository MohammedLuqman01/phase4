package com.atlassian.confluence.plugins.slack.spacetochannel.model;

public enum EventType {
    CREATE, UPDATE
}
