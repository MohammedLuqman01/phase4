package com.atlassian.confluence.plugins.slack.spacetochannel.model;

public enum PageType {
    BLOG, PAGE, QUESTION, ANSWER
}
